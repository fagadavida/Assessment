﻿using Amazon;
using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AwsApp.Services
{
    internal class SnsMessage
    {
        
        private readonly IAmazonSimpleNotificationService _sns;
        private const string region = "eu-north-1";
        private const string accessKey = "AKIATHVQLMZSVATI4CGK";
        private const string secretKey = "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";
       
        public async Task SnsTextMessage(string message, string phoneNumber) {
            var snsClient = new AmazonSimpleNotificationServiceClient(accessKey, secretKey, RegionEndpoint.GetBySystemName(region));
            // Send SMS
            try
            {
                var request = new PublishRequest
                {
                    PhoneNumber = phoneNumber,
                    Message = message
                };

                var response = await snsClient.PublishAsync(request);
                Console.WriteLine($"Message sent! Message ID: {response.MessageId}");
                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                {
                    Console.WriteLine("Message sent to topic:");
                    Console.WriteLine(message);
                }
                else
                {
                    Console.WriteLine($"HTTP status {response.HttpStatusCode}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending message: {ex.Message}");
            }
        }
    }
}
