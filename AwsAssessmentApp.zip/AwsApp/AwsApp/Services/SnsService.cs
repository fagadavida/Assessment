﻿using Amazon;
using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AwsApp.Services
{
    internal class SnsService
    {
        private readonly IAmazonSimpleNotificationService _sns;
        private const string myRegion = "eu-north-1";
        private const string accessKey = "AKIATHVQLMZSVATI4CGK";
        private const string secretKey = "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";
        public SnsService()
        {
            RegionEndpoint region = RegionEndpoint.GetBySystemName("eu-north-1");
            
            _sns = new AmazonSimpleNotificationServiceClient(accessKey, secretKey, RegionEndpoint.GetBySystemName("eu-north-1"));
        }

        public async Task PulishMessageAsync(string message)
        {
            var request = new PublishRequest
            {
                Message = message,
                TopicArn = "arn:aws:sns:eu-north-1:222634403429:Order"
            };

            var response = await _sns.PublishAsync(request);
            if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Message sent to topic:");
                Console.WriteLine(message);
            }
            else
            {
                Console.WriteLine($"HTTP status {response.HttpStatusCode}");
            }


        }

    }
}
