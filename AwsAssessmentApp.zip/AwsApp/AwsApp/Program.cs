﻿using Amazon;
using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;
using AwsApp;
using AwsApp.Services;
using System;
using System.Threading.Tasks;

class Program
{
    private static double Commission(Product product)
    {
        if(product.Price > 0)
        {
            double commission = 0.03;
            double profit = product.Price * commission;
            return profit;
        }
        return 0;
       
    }
    public static bool validatePhone(string phone)
    {
        if (!string.IsNullOrEmpty(phone))
        {
            if (phone[0] == '0' && phone.Length == 11) {
                return true;
            }
        }
        return false;
    }
    static async Task Main(string[] args)
    {
       
        Customer customer = new Customer
        {
            Name =  "David Faga",
            Email = "username@gmail.com",
            Phone = "07060914184",
            Id = 1,
        };
        Product product = new Product { Name="Maiz", Id=1, Price=5000 };
        if (validatePhone(customer.Phone) == true)
        {
            string phoneNumber = customer.Phone;
            double comission = Commission(product);
            string message = $"Hi, {customer.Name} Your Order for {product.Name} is successful: comission is {comission} ";
            SnsMessage msg = new SnsMessage();
            msg?.SnsTextMessage(message, phoneNumber);
            var snsService = new SnsService();
            snsService?.PulishMessageAsync(message);
        }
        else
        {
            Console.WriteLine("Invalid phone number");
            //Sage the log message in the database in case of any failure
        }
       
        
       
        Console.Read();
    }
}